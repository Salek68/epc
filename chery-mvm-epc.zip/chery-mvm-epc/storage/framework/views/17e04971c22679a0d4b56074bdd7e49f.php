<?php $__env->startSection('title', 'مدیریت اشتراک‌ها'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .subscription-status {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
        white-space: nowrap;
    }

    .status-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-approved {
        background: #dcfce7;
        color: #166534;
    }

    .status-rejected,
    .status-failed {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-cancelled {
        background: #e2e8f0;
        color: #475569;
    }

    .subscription-actions {
        display: flex;
        flex-direction: column;
        gap: 7px;
        min-width: 160px;
    }

    .subscription-actions form {
        margin: 0;
    }

    .btn-success {
        background: #15803d;
        color: white;
    }

    .btn-success:hover {
        background: #166534;
    }

    .btn-danger {
        background: #dc2626;
        color: white;
    }

    .btn-danger:hover {
        background: #b91c1c;
    }

    .btn-proof {
        background: #eff6ff;
        color: #1d4ed8;
        padding: 7px 10px;
        border-radius: 8px;
        display: inline-block;
        font-size: 12px;
    }

    .subscription-actions input {
        padding: 8px;
        font-size: 12px;
    }

    .subscription-stats {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        margin-bottom: 20px;
    }

    .subscription-stat {
        background: white;
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 16px;
    }

    .subscription-stat strong {
        display: block;
        font-size: 22px;
        margin-top: 5px;
    }

    @media(max-width: 560px) {
        .subscription-stats {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="page-heading">
    <h1>مدیریت اشتراک‌ها</h1>
    <p class="muted">
        بررسی درخواست‌های خرید و تمدید اشتراک کاربران و فروشندگان
    </p>
</div>

<?php if(session('success')): ?>
    <div class="card" style="background:#dcfce7;color:#166534;border-color:#bbf7d0">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="card" style="background:#fee2e2;color:#991b1b;border-color:#fecaca">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class="subscription-stats">

    <div class="subscription-stat">
        <div class="stat-label">کل درخواست‌ها</div>
        <strong><?php echo e(number_format($transactions->total())); ?></strong>
    </div>

    <div class="subscription-stat">
        <div class="stat-label">درخواست‌های در انتظار بررسی</div>
        <strong>
            <?php echo e(number_format(
                \App\Models\SubscriptionTransaction::where('status', 'pending')->count()
            )); ?>

        </strong>
    </div>

    <div class="subscription-stat">
        <div class="stat-label">پرداخت‌های تأییدشده</div>
        <strong>
            <?php echo e(number_format(
                \App\Models\SubscriptionTransaction::where('status', 'approved')->count()
            )); ?>

        </strong>
    </div>

</div>

<div class="card">

    <h2>فهرست درخواست‌های پرداخت</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>اطلاعات کاربر</th>
                    <th>نوع اشتراک</th>
                    <th>مدت</th>
                    <th>مبلغ</th>
                    <th>فیش پرداخت</th>
                    <th>وضعیت</th>
                    <th>تاریخ درخواست</th>
                    <th>عملیات</th>
                </tr>
            </thead>

            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>
                    <td>
                        <span class="code">#<?php echo e($transaction->id); ?></span>
                    </td>

                    <td>
                        <strong>
                            <?php echo e($transaction->user->name ?? 'کاربر حذف‌شده'); ?>

                        </strong>

                        <div class="muted small">
                            <?php echo e($transaction->user->email ?? '-'); ?>

                        </div>
                    </td>

                    <td>
                        <span class="badge">
                            <?php echo e($transaction->role === 'seller' ? 'فروشنده' : 'کاربر عادی'); ?>

                        </span>
                    </td>

                    <td>
                        <?php echo e(number_format($transaction->duration_days)); ?> روز
                    </td>

                    <td>
                        <span class="price">
                            <?php echo e(number_format($transaction->amount)); ?>

                        </span>
                        <small>تومان</small>
                    </td>

                    <td>
                        <?php if($transaction->document_path): ?>
                            <a class="btn-proof"
                               href="<?php echo e(\Illuminate\Support\Facades\Storage::url($transaction->document_path)); ?>"
                               target="_blank"
                               rel="noopener noreferrer">
                                مشاهده فیش
                            </a>
                        <?php else: ?>
                            <span class="muted">ثبت نشده</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php
                            $statusLabels = [
                                'pending' => 'در انتظار بررسی',
                                'approved' => 'تأیید شده',
                                'rejected' => 'رد شده',
                                'cancelled' => 'لغو شده',
                                'failed' => 'ناموفق',
                            ];
                        ?>

                        <span class="subscription-status status-<?php echo e($transaction->status); ?>">
                            <?php echo e($statusLabels[$transaction->status] ?? 'نامشخص'); ?>

                        </span>
                    </td>

                    <td>
                        <?php echo e($transaction->created_at?->format('Y/m/d H:i')); ?>

                    </td>

                    <td>
                        <div class="subscription-actions">

                            <?php if($transaction->status === 'pending'): ?>

                                <form method="POST"
                                      action="<?php echo e(route('admin.subscription-transactions.approve', $transaction->id)); ?>"
                                      onsubmit="return confirm('پرداخت تأیید و اشتراک فعال شود؟')">

                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn btn-success">
                                        تأیید و فعال‌سازی
                                    </button>
                                </form>

                                <form method="POST"
                                      action="<?php echo e(route('admin.subscription-transactions.reject', $transaction->id)); ?>"
                                      onsubmit="return confirm('درخواست پرداخت رد شود؟')">

                                    <?php echo csrf_field(); ?>

                                    <input type="text"
                                           name="admin_note"
                                           placeholder="دلیل رد درخواست">

                                    <button type="submit" class="btn btn-danger">
                                        رد درخواست
                                    </button>
                                </form>

                            <?php else: ?>

                                <span class="muted small">
                                    این درخواست بررسی شده است.
                                </span>

                                <?php if($transaction->admin_note): ?>
                                    <span class="muted small">
                                        توضیحات: <?php echo e($transaction->admin_note); ?>

                                    </span>
                                <?php endif; ?>

                                <?php if($transaction->approved_at): ?>
                                    <span class="muted small">
                                        تأیید در:
                                        <?php echo e($transaction->approved_at->format('Y/m/d H:i')); ?>

                                    </span>
                                <?php endif; ?>

                            <?php endif; ?>

                        </div>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>
                    <td colspan="9" class="empty">
                        هنوز هیچ درخواست اشتراکی ثبت نشده است.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>
        </table>
    </div>

    <div class="pagination">
        <?php echo e($transactions->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\admin\subscriptions\index.blade.php ENDPATH**/ ?>