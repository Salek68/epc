<?php $__env->startSection('title', 'لنت ترمز ' . $vehicle->name); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <a href="<?php echo e(route('brake-bank.index')); ?>" class="btn btn-secondary">
        ← بازگشت به جست‌وجو
    </a>
</div>

<section class="hero">
    <span class="badge">BRAKE PAD DATABASE</span>

    <h1 style="margin-top:12px;">
        مشخصات لنت ترمز <?php echo e($vehicle->name); ?>

    </h1>

    <p>
        اطلاعات لنت جلو، لنت عقب و خودروهای مشترک
    </p>
</section>

<div class="stats">
    <div class="stat">
        <div class="stat-label">لنت جلو</div>
        <div class="stat-value"><?php echo e($frontPads->count()); ?> مورد</div>
    </div>

    <div class="stat">
        <div class="stat-label">لنت عقب</div>
        <div class="stat-value"><?php echo e($rearPads->count()); ?> مورد</div>
    </div>

    <div class="stat">
        <div class="stat-label">موقعیت نامشخص</div>
        <div class="stat-value"><?php echo e($unknownPads->count()); ?> مورد</div>
    </div>
</div>


<section class="card">
    <h2>
        <span style="color:#2563eb;">●</span>
        لنت ترمز جلو
    </h2>

    <?php $__empty_1 = true; $__currentLoopData = $frontPads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('brake-bank.partials.pad-card', ['pad' => $pad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty">
            برای این خودرو لنت جلویی ثبت نشده است.
        </div>
    <?php endif; ?>
</section>


<section class="card">
    <h2>
        <span style="color:#15803d;">●</span>
        لنت ترمز عقب
    </h2>

    <?php $__empty_1 = true; $__currentLoopData = $rearPads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('brake-bank.partials.pad-card', ['pad' => $pad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty">
            برای این خودرو لنت عقبی ثبت نشده است.
        </div>
    <?php endif; ?>
</section>


<?php if($unknownPads->isNotEmpty()): ?>
    <section class="card">
        <h2>لنت‌های با موقعیت نامشخص</h2>

        <?php $__currentLoopData = $unknownPads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('brake-bank.partials.pad-card', ['pad' => $pad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\brake-bank\vehicle.blade.php ENDPATH**/ ?>