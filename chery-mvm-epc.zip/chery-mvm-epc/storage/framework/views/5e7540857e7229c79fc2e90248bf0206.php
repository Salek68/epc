<?php $__env->startSection('title', 'جزئیات فروشنده'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>جزئیات فروشنده</h1>
    <p class="muted">بررسی اطلاعات فروشگاه و مدارک ارسالی</p>
</div>

<?php if(session('success')): ?>
    <div class="card" style="color:#166534;background:#dcfce7">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="card" style="color:#991b1b;background:#fee2e2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class="card">

    <h2>اطلاعات فروشگاه</h2>

    <div class="detail-list">

        <div class="detail-row">
            <div class="detail-label">نام فروشگاه</div>
            <div class="detail-value"><?php echo e($seller->store_name); ?></div>
        </div>

        <div class="detail-row">
            <div class="detail-label">صاحب فروشگاه</div>
            <div class="detail-value"><?php echo e($seller->owner_name); ?></div>
        </div>

        <div class="detail-row">
            <div class="detail-label">شماره تماس</div>
            <div class="detail-value"><?php echo e($seller->phone); ?></div>
        </div>

        <div class="detail-row">
            <div class="detail-label">وب‌سایت</div>
            <div class="detail-value">
                <?php if($seller->website_url): ?>
                    <a href="<?php echo e($seller->website_url); ?>" target="_blank" rel="noopener noreferrer">
                        <?php echo e($seller->website_url); ?>

                    </a>
                <?php else: ?>
                    ثبت نشده
                <?php endif; ?>
            </div>
        </div>

        <div class="detail-row">
            <div class="detail-label">ایمیل حساب</div>
            <div class="detail-value"><?php echo e($seller->user->email ?? '-'); ?></div>
        </div>

        <div class="detail-row">
            <div class="detail-label">وضعیت فروشگاه</div>
            <div class="detail-value"><?php echo e($seller->status); ?></div>
        </div>

    </div>

    <hr style="border:0;border-top:1px solid var(--border);margin:25px 0">

    <h2>مدارک ارسالی</h2>

    <?php $__empty_1 = true; $__currentLoopData = $seller->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="detail-row">
            <strong><?php echo e($document->document_type); ?></strong>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="muted">مدرکی برای این فروشنده ثبت نشده است.</p>
    <?php endif; ?>

    <?php if($seller->admin_note): ?>
        <div class="card" style="background:#fff7ed">
            <strong>یادداشت مدیر:</strong>
            <?php echo e($seller->admin_note); ?>

        </div>
    <?php endif; ?>

    <?php if($seller->status === 'pending'): ?>

        <div class="form-actions">

            <form method="POST"
                  action="<?php echo e(route('admin.sellers.approve', $seller->id)); ?>"
                  onsubmit="return confirm('فروشنده تأیید شود؟')">

                <?php echo csrf_field(); ?>

                <button type="submit" class="btn" style="background:#15803d">
                    تأیید فروشنده
                </button>
            </form>

        </div>

        <form method="POST"
              action="<?php echo e(route('admin.sellers.reject', $seller->id)); ?>"
              style="margin-top:20px">

            <?php echo csrf_field(); ?>

            <div class="field">
                <label>دلیل رد درخواست</label>
                <textarea name="admin_note" rows="3" required><?php echo e(old('admin_note')); ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn" style="background:#dc2626">
                    رد درخواست
                </button>
            </div>

        </form>

    <?php endif; ?>

    <div class="form-actions">
        <a href="<?php echo e(route('admin.sellers.index')); ?>" class="btn btn-secondary">
            بازگشت به فهرست فروشندگان
        </a>

        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">
            بازگشت به پنل مدیریت
        </a>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\admin\sellers\show.blade.php ENDPATH**/ ?>