<?php $__env->startSection('title', 'پرداخت اشتراک'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>پرداخت اشتراک</h1>
    <p>اطلاعات درخواست اشتراک شما</p>
</div>

<?php if(session('success')): ?>
    <div class="card" style="border-right:4px solid #16a34a; margin-bottom:20px;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="card" style="border-right:4px solid #dc2626; margin-bottom:20px;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class="card">

    <h2>مشخصات اشتراک</h2>

    <div class="detail-list">

        <div>
            <strong>نوع اشتراک:</strong>
            <?php echo e($transaction->role === 'seller' ? 'فروشنده' : 'کاربر'); ?>

        </div>

        <div>
            <strong>مدت اعتبار:</strong>
            <?php echo e($transaction->duration_days); ?> روز
        </div>

        <div>
            <strong>مبلغ قابل پرداخت:</strong>
            <?php echo e(number_format($transaction->amount)); ?> تومان
        </div>

        <div>
            <strong>وضعیت درخواست:</strong>
            <?php if($transaction->status === 'pending'): ?>
                در انتظار بررسی
            <?php elseif($transaction->status === 'approved'): ?>
                تأیید شده
            <?php elseif($transaction->status === 'rejected'): ?>
                رد شده
            <?php else: ?>
                <?php echo e($transaction->status); ?>

            <?php endif; ?>
        </div>

    </div>

    <hr>

    <?php if($transaction->document_path): ?>

        <div style="margin-bottom:20px;">
            <h3>فیش ارسال‌شده</h3>

            <a href="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($transaction->document_path)); ?>"
               target="_blank">
                مشاهده تصویر فیش پرداخت
            </a>
        </div>

        <p>فیش شما ارسال شده است و درخواست در انتظار بررسی مدیریت است.</p>

    <?php else: ?>

        <h3>ارسال فیش پرداخت</h3>

        <p>
            پس از پرداخت مبلغ اشتراک، تصویر رسید پرداخت را در قسمت زیر بارگذاری کنید.
        </p>

        <form method="POST"
              action="<?php echo e(route('subscriptions.receipt', $transaction->id)); ?>"
              enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <div style="margin:20px 0;">
                <label for="receipt">تصویر فیش پرداخت</label>

                <input
                    type="file"
                    name="receipt"
                    id="receipt"
                    accept="image/jpeg,image/png,image/webp"
                    required
                >
            </div>

            <button type="submit" class="btn">
                ارسال فیش برای مدیریت
            </button>

        </form>

    <?php endif; ?>

    <div style="margin-top:25px;">
        <a href="<?php echo e(route('subscriptions.index')); ?>">بازگشت به اشتراک‌ها</a>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\subscriptions\payment.blade.php ENDPATH**/ ?>