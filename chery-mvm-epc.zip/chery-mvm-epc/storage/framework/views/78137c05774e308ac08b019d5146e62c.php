
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>وضعیت درخواست فروشندگی</title>
<link rel="stylesheet" href="<?php echo e(asset('css/partcar-system.css')); ?>?v=2.0.0"></head>
<body style="font-family:Tahoma;background:#f4f5f7;padding:40px">

<div style="max-width:600px;margin:auto;background:white;padding:30px;border-radius:12px">

    <h2>وضعیت درخواست فروشندگی</h2>

    <?php if(session('success')): ?>
        <p style="color:green"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <p>نام فروشگاه: <?php echo e($store->store_name); ?></p>
    <p>صاحب فروشگاه: <?php echo e($store->owner_name); ?></p>

    <hr>

    <?php if($store->status === 'pending'): ?>
        <h3 style="color:#d97706">در انتظار بررسی</h3>
        <p>درخواست شما ثبت شده و توسط مدیریت بررسی خواهد شد.</p>

    <?php elseif($store->status === 'approved'): ?>
        <h3 style="color:green">درخواست شما تأیید شده است</h3>
        <p>اکنون می‌توانید محصولات خود را در سایت ثبت کنید.</p>

    <?php elseif($store->status === 'rejected'): ?>
        <h3 style="color:red">درخواست شما رد شده است</h3>
        <p>دلیل رد درخواست: <?php echo e($store->admin_note); ?></p>

    <?php elseif($store->status === 'suspended'): ?>
        <h3 style="color:red">حساب فروشندگی شما تعلیق شده است</h3>
    <?php endif; ?>

</div>

</body>
</html>
<?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\seller\status.blade.php ENDPATH**/ ?>