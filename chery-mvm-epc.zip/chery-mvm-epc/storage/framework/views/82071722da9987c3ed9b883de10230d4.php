
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0B1730">

<title>کد فنی قطعات خودرو | لیست قطعات خودروهای چینی | PartCar</title>

<meta name="description" content="جست‌وجوی کد فنی قطعات خودرو و مشاهده لیست قطعات خودروهای چینی؛ شامل قطعات جک، مدیران خودرو، ام‌وی‌ام، چری و لیفان در سامانه تخصصی پارت‌کار.">

<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="author" content="PartCar">
<meta name="language" content="Persian">

<link rel="canonical" href="<?php echo e(url('/')); ?>">

<meta property="og:type" content="website">
<meta property="og:locale" content="fa_IR">
<meta property="og:site_name" content="PartCar | پارت کار">
<meta property="og:title" content="کد فنی قطعات خودرو | لیست قطعات خودروهای چینی">
<meta property="og:description" content="مرجع جست‌وجو و شناسایی کد فنی قطعات خودروهای چینی؛ بررسی قطعات جک، مدیران خودرو، چری، ام‌وی‌ام و لیفان.">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:image" content="<?php echo e(asset('branding/partcar-horizontal.png')); ?>">

<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="PartCar | کد فنی و لیست قطعات خودروهای چینی">
<meta name="twitter:description" content="جست‌وجوی کد فنی قطعات و بررسی لیست قطعات یدکی خودروهای چینی در پارت‌کار.">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">


<script type="application/ld+json">
{
  "<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>": "https://schema.org",
  "@type": "WebSite",
  "name": "PartCar | پارت کار",
  "url": "<?php echo e(url('/')); ?>",
  "description": "سامانه تخصصی جست‌وجو و شناسایی کد فنی و قطعات یدکی خودروهای چینی",
  "inLanguage": "fa-IR",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "<?php echo e(url('/')); ?>?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>


<script type="application/ld+json">
{
  "<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>": "https://schema.org",
  "@type": "Organization",
  "name": "PartCar",
  "alternateName": "پارت کار",
  "url": "<?php echo e(url('/')); ?>",
  "logo": "<?php echo e(asset('branding/partcar-horizontal.png')); ?>",
  "description": "سامانه تخصصی اطلاعات فنی و کاتالوگ قطعات خودروهای چینی"
}
</script>

<style>
:root {
    --navy: #0b1730;
    --blue: #087bfa;
    --ink: #17243a;
    --muted: #6e7d93;
    --bg: #f5f7fb;
    --line: #e5eaf1;
    --green: #159765;
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 90px;
}

body {
    margin: 0;
    background: #fff;
    color: var(--ink);
    font-family: Vazirmatn, Tahoma, sans-serif;
    font-size: 14px;
    line-height: 1.9;
}

a {
    text-decoration: none;
    color: inherit;
}

.wrap {
    width: min(1160px, calc(100% - 40px));
    margin: auto;
}

header {
    min-height: 78px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid var(--line);
    gap: 20px;
}

.brand img {
    width: 190px;
    height: auto;
    display: block;
}

nav {
    display: flex;
    align-items: center;
    gap: 23px;
    font-size: 12px;
    color: #516079;
}

nav a:hover {
    color: var(--blue);
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 11px 18px;
    border-radius: 8px;
    font: 700 12px Vazirmatn;
    transition: .18s;
    border: 1px solid transparent;
    cursor: pointer;
}

.btn-main {
    background: var(--blue);
    color: white;
}

.btn-main:hover {
    background: #0668d7;
    color: white;
    transform: translateY(-1px);
}

.btn-outline {
    border-color: #dce5f0;
    color: #263c5b;
    background: #fff;
}

.hero {
    padding: 74px 0 65px;
    background: linear-gradient(180deg, #f5f8fd 0%, #fff 100%);
    border-bottom: 1px solid var(--line);
}

.hero-grid {
    display: grid;
    grid-template-columns: 1fr 1.05fr;
    align-items: center;
    gap: 60px;
}

.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #096bd3;
    background: #eaf3ff;
    border: 1px solid #d8eaff;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 10px;
    font-weight: 800;
}

.eyebrow i {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--green);
}

h1 {
    font-size: clamp(34px, 4.7vw, 56px);
    line-height: 1.5;
    margin: 18px 0 12px;
    font-weight: 900;
    color: var(--navy);
    letter-spacing: -1px;
}

h1 span {
    color: var(--blue);
}

.hero-copy p {
    max-width: 540px;
    color: var(--muted);
    line-height: 2.2;
    font-size: 14px;
    margin: 0;
}

.hero-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 24px;
}

.hero-points {
    display: flex;
    gap: 18px;
    flex-wrap: wrap;
    margin-top: 23px;
    color: #586982;
    font-size: 11px;
}

.hero-points span:before {
    content: "✓";
    color: var(--green);
    font-weight: 900;
    margin-left: 6px;
}

.product-window {
    background: #fff;
    border: 1px solid #dfe7f1;
    border-radius: 14px;
    box-shadow: 0 22px 65px #183c6814;
    overflow: hidden;
}

.window-top {
    height: 43px;
    background: #f8fafc;
    border-bottom: 1px solid var(--line);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 15px;
    color: #8290a4;
    font-size: 10px;
}

.window-dots {
    display: flex;
    gap: 5px;
}

.window-dots b {
    width: 7px;
    height: 7px;
    background: #d4dce7;
    border-radius: 50%;
}

.window-body {
    padding: 20px;
}

.mock-search {
    height: 46px;
    border: 1px solid #dce6f2;
    border-radius: 8px;
    display: flex;
    align-items: center;
    padding: 0 13px;
    color: #8392a7;
    font-size: 11px;
    gap: 10px;
}

.mock-search strong {
    margin-right: auto;
    background: var(--blue);
    color: #fff;
    border-radius: 6px;
    padding: 6px 13px;
    font-size: 10px;
}

.mock-filter {
    display: flex;
    gap: 8px;
    margin: 14px 0;
    flex-wrap: wrap;
}

.mock-filter span {
    background: #f1f5fa;
    border: 1px solid #e6ebf2;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 9px;
    color: #61718a;
}

.mock-results {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

.mock-item {
    border: 1px solid #e9edf3;
    border-radius: 9px;
    padding: 9px;
}

.mock-item .pic {
    height: 90px;
    border-radius: 6px;
    background: linear-gradient(135deg, #f3f6fa, #e8eef6);
    display: grid;
    place-items: center;
    color: #8b9ab0;
    font-size: 25px;
}

.mock-item b {
    display: block;
    font-size: 10px;
    margin-top: 8px;
    color: #31445f;
}

.mock-item small {
    font-size: 9px;
    color: #8794a7;
}

.section {
    padding: 76px 0;
}

.section.alt {
    background: #f6f8fb;
    border-top: 1px solid var(--line);
    border-bottom: 1px solid var(--line);
}

.section-head {
    max-width: 680px;
    margin: 0 auto 34px;
    text-align: center;
}

.section-head small {
    font-size: 10px;
    color: var(--blue);
    font-weight: 800;
}

.section-head h2 {
    font-size: 29px;
    color: var(--navy);
    margin: 9px 0;
    line-height: 1.8;
}

.section-head p {
    font-size: 12px;
    line-height: 2.2;
    color: var(--muted);
    margin: 0;
}

.features {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}

.feature {
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 11px;
    padding: 20px;
}

.feature-num {
    font-size: 10px;
    color: var(--blue);
    font-weight: 800;
    letter-spacing: 1px;
}

.feature h3 {
    font-size: 14px;
    margin: 10px 0 6px;
    color: #1c2e49;
}

.feature p {
    font-size: 11px;
    color: var(--muted);
    line-height: 2.1;
    margin: 0;
}

.workflow {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}

.step {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 17px;
    background: #fff;
}

.step b {
    display: block;
    color: var(--blue);
    font-size: 11px;
    margin-bottom: 8px;
}

.step strong {
    font-size: 13px;
    color: #263a57;
}

.step p {
    font-size: 10px;
    color: var(--muted);
    line-height: 1.9;
    margin-bottom: 0;
}

.audience {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.audience-card {
    background: var(--navy);
    color: white;
    border-radius: 12px;
    padding: 25px;
}

.audience-card.light {
    background: #f0f5fc;
    color: var(--ink);
    border: 1px solid #e1eaf5;
}

.audience-card h3 {
    font-size: 18px;
    margin: 0 0 8px;
}

.audience-card p {
    font-size: 11px;
    line-height: 2.2;
    color: #c2d0e2;
    margin: 0;
}

.audience-card.light p {
    color: var(--muted);
}

/* SEO Content */

.seo-content {
    max-width: 900px;
    margin: auto;
}

.seo-content h2 {
    color: var(--navy);
    font-size: 23px;
    line-height: 1.9;
    margin: 0 0 15px;
}

.seo-content h3 {
    color: #243b5b;
    font-size: 17px;
    margin: 28px 0 9px;
}

.seo-content p {
    color: #63728a;
    font-size: 13px;
    line-height: 2.5;
    margin: 0 0 15px;
}

.seo-content strong {
    color: #263c5b;
}

.brand-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-top: 25px;
}

.brand-card {
    display: block;
    padding: 18px 13px;
    text-align: center;
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 10px;
    transition: .2s;
}

.brand-card:hover {
    border-color: var(--blue);
    transform: translateY(-3px);
    box-shadow: 0 8px 25px #183c6810;
}

.brand-card strong {
    display: block;
    color: var(--navy);
    font-size: 14px;
}

.brand-card span {
    display: block;
    color: var(--muted);
    font-size: 10px;
    margin-top: 5px;
}

.keyword-box {
    background: #f5f8fc;
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 22px;
    margin-top: 25px;
}

.keyword-box h3 {
    margin-top: 0;
}

.keyword-list {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
}

.keyword-list span {
    background: #fff;
    border: 1px solid #e0e8f2;
    border-radius: 7px;
    padding: 7px 12px;
    font-size: 11px;
    color: #52647d;
}

/* FAQ */

.faq-list {
    max-width: 850px;
    margin: auto;
}

.faq-item {
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 18px 20px;
    margin-bottom: 11px;
}

.faq-item h3 {
    font-size: 14px;
    color: var(--navy);
    margin: 0 0 8px;
}

.faq-item p {
    color: var(--muted);
    font-size: 12px;
    line-height: 2.2;
    margin: 0;
}

.cta {
    background: #0b1730;
    color: white;
    padding: 45px 0;
}

.cta-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
}

.cta h2 {
    font-size: 24px;
    margin: 0 0 5px;
}

.cta p {
    font-size: 11px;
    color: #aebed4;
    margin: 0;
}

footer {
    padding: 23px 0;
    color: #8491a4;
    font-size: 10px;
    border-top: 1px solid var(--line);
}

.foot-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

@media(max-width:850px) {
    .hero-grid {
        grid-template-columns: 1fr;
        gap: 35px;
    }

    .features {
        grid-template-columns: repeat(2, 1fr);
    }

    .workflow {
        grid-template-columns: repeat(2, 1fr);
    }

    nav {
        gap: 13px;
    }

    .brand-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width:560px) {
    .wrap {
        width: calc(100% - 28px);
    }

    header {
        height: auto;
        min-height: 68px;
        flex-wrap: wrap;
        padding: 10px 0;
    }

    .brand img {
        width: 155px;
    }

    nav {
        order: 3;
        width: 100%;
        overflow: auto;
        padding: 5px 0 8px;
        white-space: nowrap;
    }

    .hero {
        padding: 45px 0;
    }

    .hero-grid {
        gap: 27px;
    }

    h1 {
        font-size: 34px;
    }

    .hero-copy p {
        font-size: 12px;
    }

    .window-body {
        padding: 12px;
    }

    .mock-results {
        gap: 6px;
    }

    .mock-item {
        padding: 6px;
    }

    .mock-item .pic {
        height: 65px;
    }

    .features,
    .audience {
        grid-template-columns: 1fr;
    }

    .workflow {
        grid-template-columns: 1fr 1fr;
    }

    .section {
        padding: 55px 0;
    }

    .section-head h2 {
        font-size: 23px;
    }

    .cta-inner,
    .foot-inner {
        align-items: flex-start;
        flex-direction: column;
    }

    .seo-content h2 {
        font-size: 20px;
    }
}
</style>
</head>

<body>

<div class="wrap">
<header>
    <a class="brand" href="<?php echo e(url('/')); ?>" aria-label="صفحه اصلی پارت کار">
        <img src="<?php echo e(asset('branding/partcar-horizontal.png')); ?>" alt="لوگوی PartCar پارت کار">
    </a>

    <nav aria-label="منوی اصلی">
        <a href="#features">امکانات سامانه</a>
        <a href="#brands">لیست قطعات خودروها</a>
        <a href="#workflow">نحوه کار</a>
        <a href="#faq">سؤالات متداول</a>
    </nav>

    <a class="btn btn-main" href="<?php echo e(route('login')); ?>">ورود به سامانه</a>
</header>
</div>

<main>


<section class="hero">
    <div class="wrap hero-grid">

        <div class="hero-copy">

            <span class="eyebrow">
                <i></i>
                مرجع تخصصی کد فنی و قطعات یدکی خودروهای چینی
            </span>

            <h1>
                جست‌وجوی <span>کد فنی قطعات خودرو</span>
                <br>
                سریع‌تر و دقیق‌تر
            </h1>

            <p>
                پارت‌کار یک سامانه تخصصی برای جست‌وجوی کد فنی قطعات،
                شناسایی و بررسی <strong>لیست قطعات خودروهای چینی</strong> است.
                در این سامانه می‌توانید قطعات یدکی خودروهای جک، مدیران خودرو،
                ام‌وی‌ام، چری و لیفان را بر اساس نام قطعه، شماره فنی یا مدل خودرو
                جست‌وجو کنید و اطلاعات موردنیاز خود را در یک محیط یکپارچه بررسی کنید.
            </p>

            <div class="hero-actions">
                <a class="btn btn-main" href="<?php echo e(route('login')); ?>">
                    ورود و جست‌وجوی قطعات
                </a>

                <a class="btn btn-outline" href="#brands">
                    مشاهده برندهای خودرو
                </a>
            </div>

            <div class="hero-points">
                <span>جست‌وجوی کد فنی</span>
                <span>بررسی قطعات مشترک</span>
                <span>دسترسی به فروشندگان</span>
            </div>

        </div>

        <div class="product-window" aria-label="پیش‌نمایش محیط جست‌وجوی قطعات پارت‌کار">

            <div class="window-top">
                <span>محیط جست‌وجوی قطعات PartCar</span>
                <div class="window-dots"><b></b><b></b><b></b></div>
            </div>

            <div class="window-body">

                <div class="mock-search">
                    <span>⌕</span>
                    نام قطعه یا کد فنی را وارد کنید
                    <strong>جست‌وجو</strong>
                </div>

                <div class="mock-filter">
                    <span>انتخاب خودرو</span>
                    <span>دسته‌بندی قطعه</span>
                    <span>کد فنی</span>
                </div>

                <div class="mock-results">

                    <div class="mock-item">
                        <div class="pic">⚙</div>
                        <b>قطعه موتوری</b>
                        <small>کد فنی: PC-001</small>
                    </div>

                    <div class="mock-item">
                        <div class="pic">◈</div>
                        <b>قطعه جلوبندی</b>
                        <small>کد فنی: PC-002</small>
                    </div>

                    <div class="mock-item">
                        <div class="pic">▧</div>
                        <b>قطعه بدنه</b>
                        <small>کد فنی: PC-003</small>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>


<section class="section" id="features">
    <div class="wrap">

        <div class="section-head">
            <small>امکانات سامانه</small>

            <h2>
                جست‌وجوی کد فنی و شناسایی قطعات یدکی چینی
            </h2>

            <p>
                ابزارهای تخصصی پارت‌کار برای فروشندگان قطعات خودرو،
                تعمیرکاران و فعالان بازار لوازم یدکی خودروهای چینی طراحی شده‌اند.
            </p>
        </div>

        <div class="features">

            <article class="feature">
                <span class="feature-num">01 / PART NUMBER</span>
                <h3>جست‌وجوی کد فنی قطعات</h3>
                <p>
                    کد فنی یا شماره فنی قطعه را وارد کنید و اطلاعات مرتبط با آن
                    را در کاتالوگ قطعات خودرو بررسی کنید.
                </p>
            </article>

            <article class="feature">
                <span class="feature-num">02 / PART SEARCH</span>
                <h3>لیست قطعات خودروهای چینی</h3>
                <p>
                    جست‌وجو و بررسی قطعات موتوری، بدنه، جلوبندی،
                    سیستم تعلیق و سایر گروه‌های قطعات.
                </p>
            </article>

            <article class="feature">
                <span class="feature-num">03 / FITMENT</span>
                <h3>بررسی سازگاری قطعات با خودرو</h3>
                <p>
                    خودروهای سازگار با قطعه را بررسی کنید و کاربرد آن را
                    برای مدل‌های مختلف خودرو بشناسید.
                </p>
            </article>

            <article class="feature">
                <span class="feature-num">04 / CROSS REFERENCE</span>
                <h3>قطعات مشترک و کدهای جایگزین</h3>
                <p>
                    کدهای فنی متفاوتی را که ممکن است به یک قطعه مشترک
                    یا جایگزین مربوط باشند، بررسی کنید.
                </p>
            </article>

            <article class="feature">
                <span class="feature-num">05 / VISUAL CATALOG</span>
                <h3>کاتالوگ تصویری قطعات خودرو</h3>
                <p>
                    تصاویر و اطلاعات فنی قطعات را در کنار یکدیگر ببینید
                    و در شناسایی قطعه دقت بیشتری داشته باشید.
                </p>
            </article>

            <article class="feature">
                <span class="feature-num">06 / SELLERS</span>
                <h3>دسترسی به فروشندگان قطعات</h3>
                <p>
                    پیشنهادهای ثبت‌شده توسط فروشندگان را مشاهده کنید
                    و برای تهیه قطعه به فروشگاه مربوطه مراجعه کنید.
                </p>
            </article>

        </div>
    </div>
</section>


<section class="section alt" id="brands">
    <div class="wrap">

        <div class="section-head">
            <small>کاتالوگ خودروها</small>

            <h2>
                لیست قطعات و کد فنی خودروهای چینی
            </h2>

            <p>
                در پارت‌کار می‌توانید اطلاعات فنی و قطعات خودروهای چینی
                را بر اساس برند و مدل خودرو جست‌وجو کنید.
                هدف این سامانه، ساده‌تر کردن دسترسی به اطلاعات قطعات یدکی
                و شناسایی شماره فنی آن‌هاست.
            </p>
        </div>

        <div class="brand-grid">

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>لیست قطعات جک</strong>
                <span>کد فنی و قطعات خودروهای JAC</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>لیست قطعات مدیران خودرو</strong>
                <span>قطعات MVM و محصولات چری</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>لیست قطعات لیفان</strong>
                <span>کاتالوگ و اطلاعات فنی Lifan</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>لیست قطعات چری</strong>
                <span>بررسی قطعات و کد فنی Chery</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>قطعات ام‌وی‌ام</strong>
                <span>کد فنی قطعات MVM</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>قطعات کی‌ام‌سی</strong>
                <span>اطلاعات قطعات خودروهای KMC</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>قطعات برلیانس</strong>
                <span>جست‌وجوی قطعات Brilliance</span>
            </a>

            <a href="<?php echo e(route('login')); ?>" class="brand-card">
                <strong>قطعات جیلی و چانگان</strong>
                <span>اطلاعات فنی و قطعات خودرو</span>
            </a>

        </div>

        <div class="seo-content" style="margin-top:45px">

            <h2>
                کد فنی قطعات خودرو چیست و چرا اهمیت دارد؟
            </h2>

            <p>
                <strong>کد فنی قطعات خودرو</strong> یا شماره فنی، شناسه‌ای است
                که برای شناسایی یک قطعه در سیستم‌های کاتالوگ و تأمین قطعات
                مورد استفاده قرار می‌گیرد. هنگام خرید قطعات یدکی، دانستن کد فنی
                می‌تواند به تشخیص دقیق‌تر قطعه و کاهش احتمال اشتباه در انتخاب
                کمک کند.
            </p>

            <p>
                در خودروهای چینی، ممکن است قطعات ظاهراً مشابه برای مدل‌های مختلف
                تفاوت‌هایی در ابعاد، اتصالات یا شماره فنی داشته باشند.
                به همین دلیل جست‌وجوی قطعه تنها با نام عمومی آن همیشه کافی نیست.
                بررسی <strong>کد فنی قطعات</strong> در کنار مدل خودرو و اطلاعات
                سازگاری، روش دقیق‌تری برای شناسایی قطعه موردنیاز است.
            </p>

            <h3>
                جست‌وجوی کد فنی قطعات خودروهای چینی
            </h3>

            <p>
                سامانه پارت‌کار برای جست‌وجوی اطلاعات قطعات خودروهای چینی
                طراحی شده است. کاربران می‌توانند با وارد کردن نام قطعه،
                کد فنی یا انتخاب مدل خودرو، قطعات مرتبط را بررسی کنند.
                اطلاعاتی مانند شماره فنی، تصاویر قطعه، خودروهای سازگار،
                قطعات مشترک و کدهای جایگزین به شناسایی بهتر قطعه کمک می‌کنند.
            </p>

            <h3>
                لیست قطعات جک؛ بررسی کد فنی خودروهای JAC
            </h3>

            <p>
                اگر به دنبال <strong>لیست قطعات جک</strong> هستید،
                پارت‌کار امکان جست‌وجو و بررسی اطلاعات قطعات خودروهای این برند
                را فراهم می‌کند. از جمله خودروهای خانواده جک می‌توان به
                JAC J4، JAC J5، JAC S3 و JAC S5 اشاره کرد.
                با جست‌وجوی نام قطعه یا کد فنی می‌توانید اطلاعات ثبت‌شده
                مربوط به قطعه موردنظر را بررسی کنید.
            </p>

            <h3>
                لیست قطعات مدیران خودرو و محصولات MVM
            </h3>

            <p>
                <strong>لیست قطعات مدیران خودرو</strong> برای فروشندگان،
                تعمیرکاران و خریداران قطعات اهمیت زیادی دارد.
                خودروهایی مانند MVM 110، MVM 315، MVM 530،
                MVM X22، MVM X33، MVM X55 و محصولات خانواده تیگو و آریزو
                به اطلاعات فنی و کد قطعات متناسب با مدل خود نیاز دارند.
                در پارت‌کار می‌توانید قطعات ثبت‌شده این خودروها را جست‌وجو
                و اطلاعات فنی آن‌ها را بررسی کنید.
            </p>

            <h3>
                لیست قطعات لیفان و کد فنی قطعات Lifan
            </h3>

            <p>
                برای شناسایی قطعات خودروهای لیفان، تطبیق مدل خودرو با کد فنی
                اهمیت زیادی دارد. خودروهایی مانند Lifan 520، Lifan 620،
                Lifan 820، Lifan X50 و Lifan X60 از مدل‌هایی هستند که
                کاربران ممکن است برای آن‌ها به دنبال قطعات یدکی و شماره فنی
                باشند. پارت‌کار بستری برای جست‌وجو و بررسی اطلاعات قطعات
                ثبت‌شده این خودروها فراهم می‌کند.
            </p>

            <h3>
                قطعات یدکی چینی؛ از قطعات موتوری تا بدنه و جلوبندی
            </h3>

            <p>
                بازار <strong>قطعات یدکی چینی</strong> تنوع زیادی دارد.
                قطعات موتوری، قطعات بدنه، چراغ‌ها، سپرها، قطعات جلوبندی،
                سیستم تعلیق، قطعات خنک‌کننده و لوازم برقی از جمله گروه‌هایی
                هستند که برای شناسایی و انتخاب صحیح آن‌ها باید اطلاعات فنی
                و سازگاری با خودرو بررسی شود.
                پارت‌کار تلاش می‌کند اطلاعات این قطعات را در یک کاتالوگ
                تخصصی و قابل جست‌وجو در اختیار کاربران قرار دهد.
            </p>

            <div class="keyword-box">
                <h3>موضوعات قابل جست‌وجو در پارت‌کار</h3>

                <div class="keyword-list">
                    <span>کد فنی قطعات خودرو</span>
                    <span>کد فنی قطعات چینی</span>
                    <span>شماره فنی قطعات خودرو</span>
                    <span>لیست قطعات خودروهای چینی</span>
                    <span>قطعات یدکی چینی</span>
                    <span>لیست قطعات جک</span>
                    <span>لیست قطعات مدیران خودرو</span>
                    <span>لیست قطعات لیفان</span>
                    <span>قطعات ام‌وی‌ام</span>
                    <span>کد فنی قطعات چری</span>
                    <span>قطعات جلوبندی خودروهای چینی</span>
                    <span>قطعات بدنه خودروهای چینی</span>
                </div>
            </div>

        </div>
    </div>
</section>


<section class="section" id="workflow">
    <div class="wrap">

        <div class="section-head">
            <small>شروع سریع</small>

            <h2>
                چطور کد فنی و قطعه موردنظر خود را پیدا کنیم؟
            </h2>

            <p>
                برای پیدا کردن قطعه موردنیاز، کافی است چند مرحله ساده را انجام دهید.
            </p>
        </div>

        <div class="workflow">

            <div class="step">
                <b>مرحله ۱</b>
                <strong>خودرو را انتخاب کنید</strong>
                <p>برند و مدل خودرو را مشخص کنید.</p>
            </div>

            <div class="step">
                <b>مرحله ۲</b>
                <strong>قطعه یا کد فنی را جست‌وجو کنید</strong>
                <p>نام قطعه یا شماره فنی را وارد کنید.</p>
            </div>

            <div class="step">
                <b>مرحله ۳</b>
                <strong>اطلاعات قطعه را بررسی کنید</strong>
                <p>تصویر، کد فنی و خودروهای سازگار را ببینید.</p>
            </div>

            <div class="step">
                <b>مرحله ۴</b>
                <strong>فروشنده را پیدا کنید</strong>
                <p>پیشنهادهای فروش ثبت‌شده را بررسی کنید.</p>
            </div>

        </div>
    </div>
</section>


<section class="section alt" id="audience">
    <div class="wrap audience">

        <div class="audience-card">
            <h3>برای فروشندگان قطعات یدکی</h3>
            <p>
                دسترسی به اطلاعات فنی قطعات، بررسی کدهای جایگزین،
                مدیریت محصولات و معرفی لینک فروشگاه در یک محیط متمرکز.
                پارت‌کار می‌تواند به فروشندگان قطعات یدکی چینی کمک کند
                تا محصولات خود را در کنار اطلاعات تخصصی هر قطعه معرفی کنند.
            </p>
        </div>

        <div class="audience-card light">
            <h3>برای تعمیرکاران و متخصصان خودرو</h3>
            <p>
                شناسایی قطعات، جست‌وجوی کد فنی، بررسی قطعات مشترک
                و پیدا کردن قطعات سازگار برای خودروهای چینی؛
                با هدف کاهش خطا در شناسایی و انتخاب قطعه موردنیاز.
            </p>
        </div>

    </div>
</section>


<section class="section" id="faq">
    <div class="wrap">

        <div class="section-head">
            <small>سؤالات متداول</small>

            <h2>
                پرسش‌های متداول درباره کد فنی و قطعات خودرو
            </h2>

            <p>
                پاسخ پرسش‌های رایج درباره جست‌وجوی کد فنی و کاتالوگ قطعات خودروهای چینی.
            </p>
        </div>

        <div class="faq-list">

            <article class="faq-item">
                <h3>چطور کد فنی قطعه خودرو را پیدا کنم؟</h3>
                <p>
                    در پارت‌کار می‌توانید با انتخاب مدل خودرو و جست‌وجوی نام قطعه
                    یا وارد کردن شماره فنی، اطلاعات قطعات مرتبط را بررسی کنید.
                    در صورت وجود اطلاعات ثبت‌شده، کد فنی و مشخصات قطعه نمایش داده می‌شود.
                </p>
            </article>

            <article class="faq-item">
                <h3>آیا پارت‌کار لیست قطعات خودروهای چینی را دارد؟</h3>
                <p>
                    پارت‌کار یک کاتالوگ تخصصی برای جست‌وجو و بررسی قطعات خودروهای چینی است.
                    میزان اطلاعات و قطعات قابل مشاهده به مدل خودرو و داده‌های ثبت‌شده
                    در سامانه بستگی دارد.
                </p>
            </article>

            <article class="faq-item">
                <h3>آیا می‌توانم لیست قطعات جک را جست‌وجو کنم؟</h3>
                <p>
                    بله. می‌توانید مدل خودروهای جک مانند J4، J5، S3 و S5 را انتخاب کنید
                    و قطعات و کدهای فنی ثبت‌شده مرتبط با آن‌ها را جست‌وجو کنید.
                </p>
            </article>

            <article class="faq-item">
                <h3>لیست قطعات مدیران خودرو شامل چه خودروهایی است؟</h3>
                <p>
                    اطلاعات خودروهای MVM و محصولات چری مانند خانواده تیگو و آریزو
                    در محدوده کاتالوگ پارت‌کار قرار می‌گیرند.
                    قطعات قابل مشاهده به اطلاعات ثبت‌شده هر مدل بستگی دارند.
                </p>
            </article>

            <article class="faq-item">
                <h3>آیا امکان جست‌وجوی قطعات لیفان وجود دارد؟</h3>
                <p>
                    بله. امکان جست‌وجو و بررسی اطلاعات قطعات ثبت‌شده خودروهای
                    لیفان مانند 520، 620، 820، X50 و X60 در سامانه در نظر گرفته شده است.
                </p>
            </article>

            <article class="faq-item">
                <h3>آیا کد فنی متفاوت می‌تواند برای یک قطعه مشترک باشد؟</h3>
                <p>
                    در برخی موارد قطعات دارای کد فنی متفاوت ممکن است کاربرد مشترک
                    یا قابلیت جایگزینی داشته باشند. برای اطمینان باید اطلاعات فنی،
                    مشخصات قطعه و سازگاری آن با خودرو بررسی شود.
                </p>
            </article>

            <article class="faq-item">
                <h3>آیا پارت‌کار فروشگاه اینترنتی قطعات خودرو است؟</h3>
                <p>
                    پارت‌کار سامانه تخصصی جست‌وجو و شناسایی قطعات است.
                    فروشندگان می‌توانند محصولات و لینک فروشگاه خود را ثبت کنند
                    تا کاربران پیشنهادهای فروش موجود را بررسی کنند.
                </p>
            </article>

        </div>
    </div>
</section>


<script type="application/ld+json">
{
  "<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "چطور کد فنی قطعه خودرو را پیدا کنم؟",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "در پارت‌کار می‌توانید با انتخاب مدل خودرو و جست‌وجوی نام قطعه یا وارد کردن شماره فنی، اطلاعات قطعات مرتبط را بررسی کنید."
      }
    },
    {
      "@type": "Question",
      "name": "آیا پارت‌کار لیست قطعات خودروهای چینی را دارد؟",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "پارت‌کار یک کاتالوگ تخصصی برای جست‌وجو و بررسی قطعات خودروهای چینی است. میزان اطلاعات به مدل خودرو و داده‌های ثبت‌شده در سامانه بستگی دارد."
      }
    },
    {
      "@type": "Question",
      "name": "آیا می‌توانم لیست قطعات جک را جست‌وجو کنم؟",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "می‌توانید مدل خودروهای جک مانند J4، J5، S3 و S5 را انتخاب کنید و قطعات و کدهای فنی ثبت‌شده مرتبط با آن‌ها را جست‌وجو کنید."
      }
    },
    {
      "@type": "Question",
      "name": "آیا امکان جست‌وجوی قطعات لیفان وجود دارد؟",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "امکان جست‌وجو و بررسی اطلاعات قطعات ثبت‌شده خودروهای لیفان مانند 520، 620، 820، X50 و X60 در سامانه وجود دارد."
      }
    }
  ]
}
</script>


<section class="cta">
    <div class="wrap cta-inner">

        <div>
            <h2>قطعه درست را با کد فنی پیدا کنید.</h2>
            <p>
                برای جست‌وجوی قطعات یدکی خودروهای چینی وارد سامانه پارت‌کار شوید.
            </p>
        </div>

        <a class="btn btn-main" href="<?php echo e(route('login')); ?>">
            ورود به PartCar
        </a>

    </div>
</section>

</main>



</body>
</html>
<?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\landing.blade.php ENDPATH**/ ?>