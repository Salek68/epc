<?php $__env->startSection('content'); ?>

<div class="container" dir="rtl">

    
    <div class="page-heading">
        <div>
            <h1>محصولات فروشگاه من</h1>
            <p>مدیریت محصولات، لینک‌های خرید و تصاویر ثبت‌شده در فروشگاه</p>
        </div>

        <div class="flex flex-wrap gap-2">

            <a href="<?php echo e(route('seller.brake-bank.index')); ?>" class="btn">
              ثبت در بانک لنت
            </a>

            <a href="<?php echo e(route('seller.products.catalog')); ?>" class="btn btn-primary">
                + ثبت محصول جدید
            </a>

        </div>
    </div>


    
    <?php if(session('success')): ?>
        <div class="card" style="border-right:4px solid #16a34a; margin-bottom:20px; color:#166534;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>


    
    <?php if($errors->any()): ?>
        <div class="card" style="border-right:4px solid #dc2626; margin-bottom:20px; color:#b91c1c;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>


    
    <div class="stats" style="margin-bottom:24px;">

        <div class="card">
            <div class="text-muted">تعداد کل محصولات</div>
            <div class="text-2xl font-bold mt-2">
                <?php echo e(number_format($products->total())); ?>

            </div>
        </div>

        <div class="card">
            <div class="text-muted">محصولات فعال در این صفحه</div>
            <div class="text-2xl font-bold mt-2" style="color:#16a34a;">
                <?php echo e(number_format($products->getCollection()->where('is_active', true)->count())); ?>

            </div>
        </div>

        <div class="card">
            <div class="text-muted">کلیک محصولات در این صفحه</div>
            <div class="text-2xl font-bold mt-2">
                <?php echo e(number_format($products->getCollection()->sum('click_count'))); ?>

            </div>
        </div>

    </div>


    
    <div class="card">

        <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h2 class="font-bold text-lg">فهرست محصولات ثبت‌شده</h2>

            <span class="text-muted text-sm">
                صفحه <?php echo e($products->currentPage()); ?> از <?php echo e($products->lastPage() ?: 1); ?>

            </span>
        </div>

        <div class="table-wrap">

            <table>
                <thead>
                    <tr>
                        <th>تصویر</th>
                        <th>نام قطعه</th>
                        <th>کد فنی</th>
                        <th>تعداد کلیک</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            
                            <td>
                                <?php if($product->image_url): ?>
                                    <img
                                        src="<?php echo e($product->image_url); ?>"
                                        alt="<?php echo e($product->part?->name_fa); ?>"
                                        loading="lazy"
                                        style="width:65px;height:65px;object-fit:contain;border-radius:10px;background:#f8fafc;padding:5px;"
                                    >
                                <?php else: ?>
                                    <div style="width:65px;height:65px;border-radius:10px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-size:11px;color:#64748b;">
                                        بدون تصویر
                                    </div>
                                <?php endif; ?>
                            </td>


                            
                            <td>
                                <strong>
                                    <?php echo e($product->part?->name_fa ?? 'قطعه حذف شده'); ?>

                                </strong>
                            </td>


                            
                            <td>
                                <span style="direction:ltr;display:inline-block;">
                                    <?php echo e($product->part?->technical_code ?? '-'); ?>

                                </span>
                            </td>


                            
                            <td>
                                <strong>
                                    <?php echo e(number_format($product->click_count)); ?>

                                </strong>
                            </td>


                            
                            <td>
                                <?php if($product->is_active): ?>
                                    <span style="background:#dcfce7;color:#166534;padding:6px 12px;border-radius:20px;font-size:12px;">
                                        ● فعال
                                    </span>
                                <?php else: ?>
                                    <span style="background:#f1f5f9;color:#64748b;padding:6px 12px;border-radius:20px;font-size:12px;">
                                        ● غیرفعال
                                    </span>
                                <?php endif; ?>
                            </td>


                            
                            <td>
                                <div class="flex flex-wrap gap-2">

                                    <?php if($product->product_url): ?>
                                        <a
                                            href="<?php echo e($product->product_url); ?>"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            class="btn"
                                        >
                                            مشاهده لینک
                                        </a>
                                    <?php endif; ?>

                                    <a
                                        href="<?php echo e(route('seller.products.edit', $product->id)); ?>"
                                        class="btn"
                                    >
                                        ✏️ ویرایش
                                    </a>

                                    <form
                                        method="POST"
                                        action="<?php echo e(route('seller.products.destroy', $product->id)); ?>"
                                        onsubmit="return confirm('آیا از حذف این محصول مطمئن هستید؟')"
                                    >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="btn"
                                            style="background:#fee2e2;color:#b91c1c;border-color:#fecaca;"
                                        >
                                            حذف
                                        </button>
                                    </form>

                                </div>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="6" style="text-align:center;padding:45px 15px;">

                                <div style="font-size:42px;margin-bottom:12px;">
                                    📦
                                </div>

                                <strong>هنوز محصولی ثبت نکرده‌اید.</strong>

                                <p class="text-muted mt-2">
                                    برای شروع، قطعه موردنظر را از کاتالوگ انتخاب کنید.
                                </p>

                                <div class="mt-4">
                                    <a href="<?php echo e(route('seller.products.catalog')); ?>" class="btn btn-primary">
                                        + انتخاب قطعه و ثبت محصول
                                    </a>
                                </div>

                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>
            </table>

        </div>


        
        <?php if($products->hasPages()): ?>
            <div class="mt-5">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\seller\products\index.blade.php ENDPATH**/ ?>