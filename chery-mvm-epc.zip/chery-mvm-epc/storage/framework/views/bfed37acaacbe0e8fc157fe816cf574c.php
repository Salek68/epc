
<div class="card" style="border:1px solid #e2e8f0;box-shadow:none;">

    <?php
        // پیشنهادهای فروش تأییدشده دارای عکس
        $sellerImageOffer = $pad->sellerOffers
            ->where('status', 'approved')
            ->first(function ($offer) {
                return !empty($offer->image_url);
            });

        // اولویت: عکس فروشنده، سپس عکس اصلی بانک، سپس اولین عکس بانک
        $primaryImage = $pad->images
            ->firstWhere('is_primary', true)
            ?? $pad->images->first();

        $displayImage = $sellerImageOffer?->image_url
            ?: ($primaryImage
                ? asset('storage/' . $primaryImage->image_path)
                : null);
    ?>

    <div class="product-showcase">

        
        <div>
            <div class="product-showcase-image">
                <?php if($displayImage): ?>
                    <img
                        src="<?php echo e($displayImage); ?>"
                        alt="<?php echo e($pad->name); ?>"
                        loading="lazy"
                    >
                <?php else: ?>
                    <div class="product-image-placeholder">
                        <span>🛞</span>
                        <p>تصویری برای این لنت ثبت نشده است</p>
                    </div>
                <?php endif; ?>
            </div>

            
            <?php if(!$sellerImageOffer && $pad->images->count() > 1): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
                    <?php $__currentLoopData = $pad->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a
                            href="<?php echo e(asset('storage/' . $image->image_path)); ?>"
                            target="_blank"
                            style="width:65px;height:65px;border:1px solid #e2e8f0;border-radius:9px;overflow:hidden;"
                        >
                            <img
                                src="<?php echo e(asset('storage/' . $image->image_path)); ?>"
                                alt="<?php echo e($pad->name); ?>"
                                style="width:100%;height:100%;object-fit:contain;"
                            >
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($sellerImageOffer): ?>
                <small style="display:block;margin-top:8px;color:#64748b;">
                    تصویر ثبت‌شده توسط فروشنده
                </small>
            <?php endif; ?>
        </div>

        
        <div class="product-showcase-info">

            <span class="badge">
                <?php echo e($pad->position === 'front' ? 'لنت جلو' : ($pad->position === 'rear' ? 'لنت عقب' : 'موقعیت نامشخص')); ?>

            </span>

            <h2><?php echo e($pad->name); ?></h2>

            <div class="showcase-code">
                کد فنی:
                <strong><?php echo e($pad->technical_code); ?></strong>
            </div>

            <div class="showcase-price">
                <span>قیمت فعلی</span>

                <strong>
                    <?php if($pad->price !== null): ?>
                        <?php echo e(number_format($pad->price)); ?>

                        <small>تومان</small>
                    <?php else: ?>
                        قیمت ثبت نشده
                    <?php endif; ?>
                </strong>
            </div>

            <?php if($pad->carton_quantity): ?>
                <div class="detail-row">
                    <span class="detail-label">تعداد در کارتن</span>
                    <div class="detail-value">
                        <?php echo e($pad->carton_quantity); ?>

                    </div>
                </div>
            <?php endif; ?>

            <div class="form-actions">
                <a
                    href="<?php echo e(route('brake-bank.pad.show', $pad->id)); ?>"
                    class="btn"
                >
                    مشاهده مشخصات کامل
                </a>
            </div>
        </div>
    </div>

    
    <?php if($pad->compatibilities->isNotEmpty()): ?>
        <div style="border-top:1px solid #e2e8f0;padding-top:15px;margin-top:10px;">
            <strong style="display:block;margin-bottom:10px;">
                سایر مشترکات این لنت
            </strong>

            <div class="chips">
                <?php $__currentLoopData = $pad->compatibilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compatibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="chip">
                        <?php echo e($compatibility->vehicle_name); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if($pad->vehicles->isNotEmpty()): ?>
        <div style="padding-top:12px;">
            <strong style="display:block;margin-bottom:10px;">
                خودروهای ثبت‌شده برای این کد
            </strong>

            <div class="chips">
                <?php $__currentLoopData = $pad->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compatibleVehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a
                        href="<?php echo e(route('brake-bank.vehicle', $compatibleVehicle->id)); ?>"
                        class="chip"
                    >
                        <?php echo e($compatibleVehicle->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="seller-count">
        <?php echo e($pad->sellerOffers->where('status', 'approved')->count()); ?>

        فروشنده برای این لنت
    </div>

</div>
<?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\brake-bank\partials\pad-card.blade.php ENDPATH**/ ?>