<?php $__env->startSection('title', 'مدیریت فروشندگان'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>مدیریت درخواست‌های فروشندگی</h1>
    <p class="muted">مشاهده و بررسی درخواست‌های ثبت‌شده فروشندگان</p>
</div>

<?php if(session('success')): ?>
    <div class="card" style="color:#166534;background:#dcfce7">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="card">
    <h2>فهرست فروشندگان</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>فروشگاه</th>
                    <th>صاحب فروشگاه</th>
                    <th>شماره تماس</th>
                    <th>وضعیت</th>
                    <th>جزئیات</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($seller->store_name); ?></strong></td>
                        <td><?php echo e($seller->owner_name); ?></td>
                        <td><?php echo e($seller->phone); ?></td>

                        <td>
                            <?php if($seller->status === 'pending'): ?>
                                <span class="badge" style="background:#fef3c7;color:#92400e">
                                    در انتظار بررسی
                                </span>
                            <?php elseif($seller->status === 'approved'): ?>
                                <span class="badge" style="background:#dcfce7;color:#166534">
                                    تأیید شده
                                </span>
                            <?php elseif($seller->status === 'rejected'): ?>
                                <span class="badge" style="background:#fee2e2;color:#991b1b">
                                    رد شده
                                </span>
                            <?php else: ?>
                                <span class="badge"><?php echo e($seller->status); ?></span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <a class="btn"
                               href="<?php echo e(route('admin.sellers.show', $seller->id)); ?>">
                                مشاهده جزئیات
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="empty">
                            هنوز درخواستی ثبت نشده است.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <?php echo e($sellers->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\admin\sellers\index.blade.php ENDPATH**/ ?>