<?php $__env->startSection('title', 'اشتراک من'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>اشتراک من</h1>
    <p>وضعیت اشتراک‌ها و سوابق پرداخت حساب شما</p>
</div>

<?php if(session('success')): ?>
    <div class="card" style="border-right:4px solid #16a34a; margin-bottom:20px;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:20px;">

    
    <div class="card">
        <h2>اشتراک کاربری</h2>

        <?php if($activeUserSubscription): ?>

            <div style="color:#16a34a; font-weight:bold;">
                اشتراک فعال
            </div>

            <p>
                تاریخ شروع:
                <?php echo e($activeUserSubscription->starts_at->format('Y/m/d')); ?>

            </p>

            <p>
                تاریخ پایان:
                <?php echo e($activeUserSubscription->expires_at->format('Y/m/d')); ?>

            </p>

            <h3>
                <?php echo e($activeUserSubscription->remainingDays()); ?>

                روز باقی‌مانده
            </h3>

        <?php else: ?>

            <div style="color:#dc2626; font-weight:bold;">
                اشتراک فعال ندارید
            </div>

            <p>برای استفاده از کاتالوگ، اشتراک کاربری تهیه کنید.</p>

        <?php endif; ?>

        <a href="<?php echo e(route('subscriptions.index')); ?>" class="btn">
            خرید یا تمدید اشتراک کاربری
        </a>
    </div>


    
    <div class="card">
        <h2>اشتراک فروشندگی</h2>

        <?php if($activeSellerSubscription): ?>

            <div style="color:#16a34a; font-weight:bold;">
                اشتراک فعال
            </div>

            <p>
                تاریخ شروع:
                <?php echo e($activeSellerSubscription->starts_at->format('Y/m/d')); ?>

            </p>

            <p>
                تاریخ پایان:
                <?php echo e($activeSellerSubscription->expires_at->format('Y/m/d')); ?>

            </p>

            <h3>
                <?php echo e($activeSellerSubscription->remainingDays()); ?>

                روز باقی‌مانده
            </h3>

        <?php else: ?>

            <div style="color:#dc2626; font-weight:bold;">
                اشتراک فعال ندارید
            </div>

            <p>برای مدیریت محصولات فروشگاه، اشتراک فروشندگی تهیه کنید.</p>

        <?php endif; ?>

        <a href="<?php echo e(route('subscriptions.index')); ?>" class="btn">
            خرید یا تمدید اشتراک فروشندگی
        </a>
    </div>

</div>



<div class="card" style="margin-top:25px;">

    <h2>سوابق اشتراک‌ها</h2>

    <?php if($subscriptions->isEmpty()): ?>

        <p>هنوز اشتراکی برای حساب شما ثبت نشده است.</p>

    <?php else: ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>نوع اشتراک</th>
                        <th>مدت</th>
                        <th>شروع</th>
                        <th>پایان</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($subscription->role === 'seller' ? 'فروشنده' : 'کاربر'); ?>

                            </td>

                            <td>
                                <?php echo e($subscription->duration_days); ?> روز
                            </td>

                            <td>
                                <?php echo e($subscription->starts_at->format('Y/m/d')); ?>

                            </td>

                            <td>
                                <?php echo e($subscription->expires_at->format('Y/m/d')); ?>

                            </td>

                            <td>
                                <?php if($subscription->isValid()): ?>
                                    <span style="color:#16a34a;">فعال</span>
                                <?php elseif($subscription->status === 'cancelled'): ?>
                                    <span style="color:#dc2626;">لغو شده</span>
                                <?php else: ?>
                                    <span style="color:#d97706;">منقضی شده</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</div>



<div class="card" style="margin-top:25px;">

    <h2>سوابق درخواست و پرداخت</h2>

    <?php if($transactions->isEmpty()): ?>

        <p>هنوز درخواست پرداختی ثبت نکرده‌اید.</p>

    <?php else: ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>نوع اشتراک</th>
                        <th>مدت</th>
                        <th>مبلغ</th>
                        <th>تاریخ درخواست</th>
                        <th>وضعیت</th>
                        <th>جزئیات</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($transaction->role === 'seller' ? 'فروشنده' : 'کاربر'); ?>

                            </td>

                            <td>
                                <?php echo e($transaction->duration_days); ?> روز
                            </td>

                            <td>
                                <?php echo e(number_format($transaction->amount)); ?> تومان
                            </td>

                            <td>
                                <?php echo e($transaction->created_at->format('Y/m/d')); ?>

                            </td>

                            <td>
                                <?php switch($transaction->status):
                                    case ('pending'): ?>
                                        <span style="color:#d97706;">در انتظار بررسی</span>
                                        <?php break; ?>

                                    <?php case ('approved'): ?>
                                        <span style="color:#16a34a;">تأیید شده</span>
                                        <?php break; ?>

                                    <?php case ('rejected'): ?>
                                        <span style="color:#dc2626;">رد شده</span>
                                        <?php break; ?>

                                    <?php default: ?>
                                        <?php echo e($transaction->status); ?>

                                <?php endswitch; ?>
                            </td>

                            <td>
                                <?php if($transaction->status === 'pending'): ?>
                                    <a href="<?php echo e(route('subscriptions.payment', $transaction->id)); ?>">
                                        مشاهده درخواست
                                    </a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</div>

<div style="margin-top:20px;">
    <a href="<?php echo e(route('subscriptions.index')); ?>" class="btn">
        مشاهده پلن‌های اشتراک
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\subscriptions\my.blade.php ENDPATH**/ ?>