<?php $__env->startSection('title', 'مشخصات لنت ' . $pad->technical_code); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
        ← بازگشت
    </a>
</div>

<section class="hero">
    <span class="badge">BRAKE PAD DETAILS</span>

    <h1 style="margin-top:12px;"><?php echo e($pad->name); ?></h1>

    <p>
        مشخصات فنی، قیمت فعلی و خودروهای سازگار با این لنت
    </p>
</section>
<?php
    $sellerOffers = $pad->sellerOffers;
    $sellerCount = $sellerOffers->count();

    // اولین عکس ثبت‌شده توسط فروشندگان
    $sellerImage = $sellerOffers->first(
        fn ($offer) => !empty($offer->image_url)
    )?->image_url;

    // اگر فروشنده عکسی نداشت، عکس بانک نمایش داده شود
    $fallbackImage = $pad->images->first()?->image_path;

    $displayImage = $sellerImage
        ?: ($fallbackImage ? asset('storage/' . $fallbackImage) : null);
?>
<div class="card">
    <h2>گالری تصاویر لنت</h2>

     <?php if($displayImage): ?>
            <div class="seller-main-image">
                <img
                    src="<?php echo e($displayImage); ?>"
                    alt="<?php echo e($pad->name); ?>"
                    loading="lazy"
                >
             
            </div>
        <?php endif; ?>
</div>

<div class="card">
    <h2>مشخصات فنی</h2>

    <div class="detail-list">

        <div class="detail-row">
            <div class="detail-label">نام لنت</div>
            <div class="detail-value"><?php echo e($pad->name); ?></div>
        </div>

        <div class="detail-row">
            <div class="detail-label">کد فنی</div>
            <div class="detail-value code">
                <?php echo e($pad->technical_code); ?>

            </div>
        </div>

        <div class="detail-row">
            <div class="detail-label">موقعیت لنت</div>
            <div class="detail-value">
                <?php if($pad->position === 'front'): ?>
                    لنت جلو
                <?php elseif($pad->position === 'rear'): ?>
                    لنت عقب
                <?php else: ?>
                    نامشخص
                <?php endif; ?>
            </div>
        </div>

        <div class="detail-row">
            <div class="detail-label">قیمت فعلی</div>
            <div class="detail-value price">
                <?php echo e($pad->price !== null ? number_format($pad->price) . ' تومان' : 'ثبت نشده'); ?>

            </div>
        </div>

        <div class="detail-row">
            <div class="detail-label">تعداد در کارتن</div>
            <div class="detail-value">
                <?php echo e($pad->carton_quantity ?? 'ثبت نشده'); ?>

            </div>
        </div>

    </div>
</div>
<div class="card">
    <?php echo $__env->make('brake-bank.partials.seller-offers', [
        'pad' => $pad
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<div class="card">
    <h2>خودروهای سازگار</h2>

    <div class="chips">
        <?php $__empty_1 = true; $__currentLoopData = $pad->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a
                href="<?php echo e(route('brake-bank.vehicle', $vehicle->id)); ?>"
                class="chip"
            >
                <?php echo e($vehicle->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">خودرویی برای این لنت ثبت نشده است.</div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h2>سایر مشترکات</h2>

    <div class="chips">
        <?php $__empty_1 = true; $__currentLoopData = $pad->compatibilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compatibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span class="chip">
                <?php echo e($compatibility->vehicle_name); ?>

            </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">مشترکات دیگری ثبت نشده است.</div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\brake-bank\show.blade.php ENDPATH**/ ?>