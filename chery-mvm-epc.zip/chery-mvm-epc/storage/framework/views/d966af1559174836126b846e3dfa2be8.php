<?php $__env->startSection('title', 'بانک اطلاعات لنت خودروها'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>بانک اطلاعات لنت ترمز</h1>
    <p class="muted">
        جست‌وجوی خودرو و مشاهده مشخصات لنت جلو و عقب و خودروهای مشترک
    </p>
</div>

<section class="hero">
    <h1>بانک هوشمند لنت خودروهای چینی</h1>
    <p>
        مدل خودرو را جست‌وجو کن تا کد فنی، قیمت، تصاویر و مشترکات لنت‌ها را ببینی.
    </p>
</section>

<div class="card">
    <h2>جست‌وجوی خودرو</h2>

    <form method="GET" action="<?php echo e(route('brake-bank.index')); ?>">
        <div class="field">
            <label for="q">نام خودرو</label>

            <input
                type="search"
                name="q"
                id="q"
                value="<?php echo e($q); ?>"
                placeholder="مثلاً KMC X5 یا JAC S5"
                autocomplete="off"
                autofocus
            >
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">
                جست‌وجوی خودرو
            </button>

            <a href="<?php echo e(route('brake-bank.index')); ?>" class="btn btn-secondary">
                پاک کردن
            </a>
        </div>
    </form>
</div>

<?php if($q !== ''): ?>
    <div class="card">
        <h2>نتایج جست‌وجو</h2>

        <?php $__empty_1 = true; $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a
                href="<?php echo e(route('brake-bank.vehicle', $vehicle->id)); ?>"
                class="category-item"
                style="margin-bottom:10px;"
            >
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;">
                    <div>
                        <strong><?php echo e($vehicle->name); ?></strong>
                        <small>
                            <?php echo e($vehicle->brake_pads_count); ?> لنت ثبت‌شده
                        </small>
                    </div>

                    <span class="badge">مشاهده لنت‌ها ←</span>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">
                <div style="font-size:38px;">🔎</div>
                خودرویی با این نام پیدا نشد.
            </div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="card">
        <h2>خودروهای ثبت‌شده</h2>

        <div class="category-grid">
            <?php $__empty_1 = true; $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a
                    href="<?php echo e(route('brake-bank.vehicle', $vehicle->id)); ?>"
                    class="category-item"
                >
                    <strong><?php echo e($vehicle->name); ?></strong>
                    <small>
                        <?php echo e($vehicle->brake_pads_count); ?> لنت
                    </small>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty">
                    هنوز خودرویی در بانک لنت ثبت نشده است.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\brake-bank\index.blade.php ENDPATH**/ ?>