<?php $__env->startSection('title', 'درخواست‌های فروش لنت من'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .offer-page {
        direction: rtl;
        color: #e8eef8;
        padding: 24px 0;
    }

    .offer-header {
        background: linear-gradient(120deg,#101b30,#19355b,#10434b);
        border-radius: 18px;
        padding: 25px;
        margin-bottom: 22px;
    }

    .offer-header h1 {
        margin: 0 0 10px;
        color: white;
    }

    .offer-header p {
        color: #c5d4e9;
        margin: 0;
    }

    .offer-back {
        display: inline-block;
        margin-top: 17px;
        color: #55e0d5;
        text-decoration: none;
    }

    .offer-table-wrap {
        overflow-x: auto;
        background: #101b2d;
        border: 1px solid #293b55;
        border-radius: 15px;
    }

    .offer-table {
        width: 100%;
        min-width: 750px;
        border-collapse: collapse;
    }

    .offer-table th,
    .offer-table td {
        padding: 15px;
        text-align: right;
        border-bottom: 1px solid #293b55;
    }

    .offer-table th {
        color: #55e0d5;
        font-size: 12px;
        background: #14243a;
    }

    .offer-table td {
        color: #000000;
        font-size: 13px;
    }

    .offer-table a {
        color: #000000;
        text-decoration: none;
    }

    .offer-status {
        display: inline-block;
        padding: 6px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
    }

    .pending {
        color: #ffd68a;
        background: rgba(245,158,11,.13);
    }

    .approved {
        color: #72e5a5;
        background: rgba(34,197,94,.13);
    }

    .rejected,
    .suspended {
        color: #ff9292;
        background: rgba(239,68,68,.13);
    }

    .offer-empty {
        padding: 45px 20px;
        text-align: center;
        background: #101b2d;
        border: 1px dashed #40516a;
        border-radius: 15px;
        color: #aebed2;
    }
</style>

<div class="offer-page">

    <div class="offer-header">
        <h1>درخواست‌های فروش لنت من</h1>

        <p>
            در این قسمت وضعیت درخواست‌های ثبت‌شده برای فروش لنت را مشاهده می‌کنید.
        </p>

        <a href="<?php echo e(route('seller.brake-bank.index')); ?>" class="offer-back">
            ← بازگشت به بانک لنت
        </a>
    </div>

    <?php if($offers->count()): ?>

        <div class="offer-table-wrap">

            <table class="offer-table">

                <thead>
                    <tr>
                        <th>کد فنی</th>
                        <th>نام لنت</th>
                        <th>برندها</th>
                        <th>لینک محصول</th>
                        <th>وضعیت</th>
                        <th>تاریخ ثبت</th>
                        <th>توضیحات مدیر</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $statusLabels = [
                                'pending' => 'در انتظار بررسی',
                                'approved' => 'تأیید شده',
                                'rejected' => 'رد شده',
                                'suspended' => 'تعلیق شده',
                            ];
                        ?>

                        <tr>

                            <td>
                                <?php echo e($offer->brakePad?->technical_code ?? '—'); ?>

                            </td>

                            <td>
                                <?php echo e($offer->brakePad?->name ?? 'لنت حذف شده'); ?>

                            </td>

                            <td>
                                <?php echo e($offer->brands->pluck('name')->implode('، ') ?: '—'); ?>

                            </td>

                            <td>
                                <a href="<?php echo e($offer->product_url); ?>"
                                   target="_blank"
                                   rel="noopener noreferrer">
                                    مشاهده محصول
                                </a>
                            </td>

                            <td>
                                <span class="offer-status <?php echo e($offer->status); ?>">
                                    <?php echo e($statusLabels[$offer->status] ?? $offer->status); ?>

                                </span>
                            </td>

                            <td>
                                <?php echo e($offer->created_at?->format('Y/m/d') ?? '—'); ?>

                            </td>

                            <td>
                                <?php echo e($offer->admin_note ?: '—'); ?>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

        </div>

        <div style="margin-top:22px">
            <?php echo e($offers->links()); ?>

        </div>

    <?php else: ?>

        <div class="offer-empty">
            <h3>هنوز درخواستی ثبت نکرده‌اید</h3>

            <p>
                از بانک لنت، لنت موردنظر خود را انتخاب و درخواست فروش ثبت کنید.
            </p>

            <a href="<?php echo e(route('seller.brake-bank.index')); ?>"
               style="color:#55e0d5">
                مشاهده بانک لنت
            </a>
        </div>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\saleh\Desktop\epc\epc\chery-mvm-epc\resources\views\seller\brake-bank\offers.blade.php ENDPATH**/ ?>