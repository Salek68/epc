<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0B1730">
<meta name="description" content="PartCar؛ سامانه تخصصی جست‌وجو و شناسایی قطعات خودروهای چینی">
<title>PartCar | پارت کار — سامانه هوشمند قطعات خودرو</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
:root{--navy:#0b1730;--blue:#087bfa;--ink:#17243a;--muted:#6e7d93;--bg:#f5f7fb;--line:#e5eaf1}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#fff;color:var(--ink);font-family:Vazirmatn,Tahoma,sans-serif;font-size:14px}
a{text-decoration:none;color:inherit}.wrap{width:min(1160px,calc(100% - 40px));margin:auto}
header{height:78px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line);gap:20px}
.brand img{width:190px;height:auto;display:block}
nav{display:flex;align-items:center;gap:26px;font-size:12px;color:#516079}
nav a:hover{color:var(--blue)}
.btn{display:inline-flex;align-items:center;justify-content:center;padding:11px 18px;border-radius:8px;font:700 12px Vazirmatn;transition:.18s;border:1px solid transparent}
.btn-main{background:var(--blue);color:white}.btn-main:hover{background:#0668d7;color:white;transform:translateY(-1px)}
.btn-outline{border-color:#dce5f0;color:#263c5b;background:#fff}
.hero{padding:74px 0 65px;background:linear-gradient(180deg,#f5f8fd 0%,#fff 100%);border-bottom:1px solid var(--line)}
.hero-grid{display:grid;grid-template-columns:1fr 1.05fr;align-items:center;gap:60px}
.eyebrow{display:inline-flex;align-items:center;gap:8px;color:#096bd3;background:#eaf3ff;border:1px solid #d8eaff;border-radius:6px;padding:6px 10px;font-size:10px;font-weight:800}
.eyebrow i{width:6px;height:6px;border-radius:50%;background:#159765}
h1{font-size:clamp(34px,4.7vw,58px);line-height:1.45;margin:18px 0 12px;font-weight:900;color:var(--navy);letter-spacing:-1px}
h1 span{color:var(--blue)}
.hero-copy p{max-width:530px;color:var(--muted);line-height:2.1;font-size:14px;margin:0}
.hero-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
.hero-points{display:flex;gap:18px;flex-wrap:wrap;margin-top:23px;color:#586982;font-size:11px}
.hero-points span:before{content:"✓";color:#159765;font-weight:900;margin-left:6px}
.product-window{background:#fff;border:1px solid #dfe7f1;border-radius:14px;box-shadow:0 22px 65px #183c6814;overflow:hidden}
.window-top{height:43px;background:#f8fafc;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;padding:0 15px;color:#8290a4;font-size:10px}
.window-dots{display:flex;gap:5px}.window-dots b{width:7px;height:7px;background:#d4dce7;border-radius:50%}
.window-body{padding:20px}
.mock-search{height:46px;border:1px solid #dce6f2;border-radius:8px;display:flex;align-items:center;padding:0 13px;color:#8392a7;font-size:11px;gap:10px}
.mock-search strong{margin-right:auto;background:var(--blue);color:#fff;border-radius:6px;padding:6px 13px;font-size:10px}
.mock-filter{display:flex;gap:8px;margin:14px 0}.mock-filter span{background:#f1f5fa;border:1px solid #e6ebf2;border-radius:6px;padding:6px 10px;font-size:9px;color:#61718a}
.mock-results{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.mock-item{border:1px solid #e9edf3;border-radius:9px;padding:9px}
.mock-item .pic{height:90px;border-radius:6px;background:linear-gradient(135deg,#f3f6fa,#e8eef6);display:grid;place-items:center;color:#8b9ab0;font-size:25px}
.mock-item b{display:block;font-size:10px;margin-top:8px;color:#31445f}.mock-item small{font-size:9px;color:#8794a7}
.section{padding:76px 0}.section.alt{background:#f6f8fb;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.section-head{max-width:650px;margin:0 auto 34px;text-align:center}.section-head small{font-size:10px;color:var(--blue);font-weight:800}.section-head h2{font-size:30px;color:var(--navy);margin:9px 0}.section-head p{font-size:12px;line-height:2;color:var(--muted);margin:0}
.features{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.feature{background:#fff;border:1px solid var(--line);border-radius:11px;padding:20px}
.feature-num{font-size:10px;color:var(--blue);font-weight:800;letter-spacing:1px}
.feature h3{font-size:14px;margin:10px 0 6px;color:#1c2e49}.feature p{font-size:11px;color:var(--muted);line-height:2;margin:0}
.workflow{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.step{border:1px solid var(--line);border-radius:10px;padding:17px;background:#fff}
.step b{display:block;color:var(--blue);font-size:11px;margin-bottom:8px}.step strong{font-size:13px;color:#263a57}.step p{font-size:10px;color:var(--muted);line-height:1.9;margin-bottom:0}
.audience{display:grid;grid-template-columns:1fr 1fr;gap:15px}
.audience-card{background:var(--navy);color:white;border-radius:12px;padding:25px}
.audience-card.light{background:#f0f5fc;color:var(--ink);border:1px solid #e1eaf5}
.audience-card h3{font-size:18px;margin:0 0 8px}.audience-card p{font-size:11px;line-height:2;color:#c2d0e2;margin:0}.audience-card.light p{color:var(--muted)}
.cta{background:#0b1730;color:white;padding:45px 0}.cta-inner{display:flex;align-items:center;justify-content:space-between;gap:25px}.cta h2{font-size:24px;margin:0 0 5px}.cta p{font-size:11px;color:#aebed4;margin:0}
footer{padding:23px 0;color:#8491a4;font-size:10px;border-top:1px solid var(--line)}.foot-inner{display:flex;align-items:center;justify-content:space-between;gap:20px}
@media(max-width:850px){.hero-grid{grid-template-columns:1fr;gap:35px}.features{grid-template-columns:repeat(2,1fr)}.workflow{grid-template-columns:repeat(2,1fr)}nav{gap:13px}}
@media(max-width:560px){.wrap{width:calc(100% - 28px)}header{height:auto;min-height:68px;flex-wrap:wrap;padding:10px 0}.brand img{width:155px}nav{order:3;width:100%;overflow:auto;padding:5px 0 8px;white-space:nowrap}.hero{padding:45px 0}.hero-grid{gap:27px}h1{font-size:34px}.hero-copy p{font-size:12px}.window-body{padding:12px}.mock-results{gap:6px}.mock-item{padding:6px}.mock-item .pic{height:65px}.features,.audience{grid-template-columns:1fr}.workflow{grid-template-columns:1fr 1fr}.section{padding:55px 0}.section-head h2{font-size:24px}.cta-inner,.foot-inner{align-items:flex-start;flex-direction:column}}
</style>
</head>
<body>
<div class="wrap">
<header>
 <a class="brand" href="{{ url('/') }}"><img src="{{ asset('branding/partcar-horizontal.png') }}" alt="PartCar پارت کار"></a>
 <nav><a href="#features">امکانات سامانه</a><a href="#workflow">نحوه کار</a><a href="#audience">مخاطبان</a></nav>
 <a class="btn btn-main" href="{{ route('login') }}">ورود به سامانه</a>
</header>
</div>

<section class="hero">
 <div class="wrap hero-grid">
  <div class="hero-copy">
   <span class="eyebrow"><i></i> سامانه تخصصی قطعات خودروهای چینی</span>
   <h1>پیدا کردن قطعه،<br><span>ساده و مطمئن.</span></h1>
   <p>PartCar یک سامانه تخصصی برای جست‌وجو، شناسایی و بررسی قطعات خودرو است. نام قطعه، کد فنی یا مدل خودرو را وارد کنید و سریع‌تر به اطلاعات موردنیاز برسید.</p>
   <div class="hero-actions">
    <a class="btn btn-main" href="{{ route('login') }}">ورود به سامانه</a>
    <a class="btn btn-outline" href="#features">آشنایی با امکانات</a>
   </div>
   <div class="hero-points"><span>جست‌وجوی بر اساس کد فنی</span><span>بررسی قطعات مشترک</span><span>دسترسی به فروشندگان</span></div>
  </div>
  <div class="product-window" aria-label="پیش‌نمایش محیط سامانه">
   <div class="window-top"><span>محیط جست‌وجوی PartCar</span><div class="window-dots"><b></b><b></b><b></b></div></div>
   <div class="window-body">
    <div class="mock-search"><span>⌕</span> نام قطعه یا کد فنی را وارد کنید <strong>جست‌وجو</strong></div>
    <div class="mock-filter"><span>انتخاب خودرو</span><span>دسته‌بندی قطعه</span><span>کد فنی</span></div>
    <div class="mock-results">
     <div class="mock-item"><div class="pic">⚙</div><b>قطعه موتوری</b><small>کد فنی: PC-001</small></div>
     <div class="mock-item"><div class="pic">◈</div><b>قطعه جلوبندی</b><small>کد فنی: PC-002</small></div>
     <div class="mock-item"><div class="pic">▧</div><b>قطعه بدنه</b><small>کد فنی: PC-003</small></div>
    </div>
   </div>
  </div>
 </div>
</section>

<section class="section" id="features">
 <div class="wrap">
  <div class="section-head"><small>امکانات سامانه</small><h2>ابزارهای تخصصی برای بازار قطعات</h2><p>اطلاعات قطعات را در یک محیط منظم پیدا کنید، تطبیق دهید و تصمیم دقیق‌تری بگیرید.</p></div>
  <div class="features">
   <article class="feature"><span class="feature-num">01 / SEARCH</span><h3>جست‌وجوی چندمسیره</h3><p>جست‌وجو بر اساس نام قطعه، کد فنی، خودرو و دسته‌بندی.</p></article>
   <article class="feature"><span class="feature-num">02 / FITMENT</span><h3>بررسی سازگاری خودرو</h3><p>مشاهده خودروهای سازگار و قطعات قابل استفاده برای چند مدل.</p></article>
   <article class="feature"><span class="feature-num">03 / CROSS-REFERENCE</span><h3>قطعات مشترک و جایگزین</h3><p>شناسایی کدهای فنی متفاوت با کاربرد مشترک و قطعات جایگزین.</p></article>
   <article class="feature"><span class="feature-num">04 / VISUAL CATALOG</span><h3>کاتالوگ تصویری</h3><p>بررسی تصاویر و اطلاعات فنی قطعات در کنار یکدیگر.</p></article>
   <article class="feature"><span class="feature-num">05 / SELLERS</span><h3>دسترسی به فروشندگان</h3><p>مشاهده پیشنهادها و لینک‌های فروش ثبت‌شده توسط فروشندگان.</p></article>
   <article class="feature"><span class="feature-num">06 / BRAKE BANK</span><h3>بانک اطلاعات لنت</h3><p>جست‌وجو و بررسی اطلاعات لنت و موارد مشترک بین خودروها.</p></article>
  </div>
 </div>
</section>

<section class="section alt" id="workflow">
 <div class="wrap">
  <div class="section-head"><small>شروع سریع</small><h2>از جست‌وجو تا شناسایی قطعه</h2><p>فرآیند کار ساده طراحی شده تا بدون گشتن بین صفحات متعدد به نتیجه برسید.</p></div>
  <div class="workflow">
   <div class="step"><b>مرحله ۱</b><strong>خودرو را انتخاب کنید</strong><p>برند و مدل خودرو را مشخص کنید.</p></div>
   <div class="step"><b>مرحله ۲</b><strong>قطعه را جست‌وجو کنید</strong><p>نام قطعه یا کد فنی را وارد کنید.</p></div>
   <div class="step"><b>مرحله ۳</b><strong>اطلاعات را بررسی کنید</strong><p>تصویر، کد و سازگاری را ببینید.</p></div>
   <div class="step"><b>مرحله ۴</b><strong>فروشنده را پیدا کنید</strong><p>پیشنهادهای ثبت‌شده را بررسی کنید.</p></div>
  </div>
 </div>
</section>

<section class="section" id="audience">
 <div class="wrap audience">
  <div class="audience-card"><h3>برای فروشندگان قطعات</h3><p>دسترسی سریع‌تر به اطلاعات فنی، مدیریت محصولات و معرفی موجودی و لینک فروشگاه در یک محیط متمرکز.</p></div>
  <div class="audience-card light"><h3>برای تعمیرکاران و متخصصان</h3><p>شناسایی قطعات، بررسی کدهای فنی و پیدا کردن قطعات سازگار برای تصمیم‌گیری مطمئن‌تر.</p></div>
 </div>
</section>

<section class="cta">
 <div class="wrap cta-inner"><div><h2>جست‌وجوی قطعات را حرفه‌ای‌تر انجام دهید.</h2><p>برای استفاده از امکانات PartCar وارد حساب کاربری خود شوید.</p></div><a class="btn btn-main" href="{{ route('login') }}">ورود به PartCar</a></div>
</section>
<footer><div class="wrap foot-inner"><span>© {{ date('Y') }} PartCar | پارت کار</span><span>قطعه درست، انتخاب مطمئن</span></div></footer>
</body>
</html>
